clear
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Objective: We are testing the approximation performance of using the Log-sum-exp function
% Date: 08/30/2023
% Author: Ming Li
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% We try to consider three obstacles (2-D)

%% Add multiple obstacles in the scenario
%Obstacle 1
Obstacle_1.center=[0.6775,-1.8844].';
Obstacle_1.radius=0.3;
%Obstacle 2
Obstacle_2.center=[0.28182,1.9802].';
Obstacle_2.radius=0.3;
%Obstacle 3
Obstacle_3.center=[-1.7593,-0.95163].';
Obstacle_3.radius=0.3;

x_store=[];
x_approx_store=[];
eta=[0.2,0.5,0.8,2];
figure(1)
for i=1:length(eta)
    for x=-3:0.01:3
        for y=-3:0.01:3
            h1=(x-Obstacle_1.center(1)).^2+(y-Obstacle_1.center(2)).^2-Obstacle_1.radius^2;
            h2=(x-Obstacle_2.center(1)).^2+(y-Obstacle_2.center(2)).^2-Obstacle_2.radius^2;
            h3=(x-Obstacle_3.center(1)).^2+(y-Obstacle_3.center(2)).^2-Obstacle_3.radius^2;
            h=-1/eta(i)*log(exp(-eta(i)*h1)+exp(-eta(i)*h2)+exp(-eta(i)*h3));
            if h1<0||h2<0||h3<0
                x_store=[x_store,[x,y].'];
            end
            if h<0
                x_approx_store=[x_approx_store,[x,y].'];
            end
        end
    end
    subplot(2,2,i)
    h1=plot(x_approx_store(1,:),x_approx_store(2,:),'b.');
    hold on
    h2=plot(x_store(1,:),x_store(2,:),'r.');
    xlabel('x')
    ylabel('y')
    %     legend([h1,h2],'Original CBF','Approximated CBF')
    set(gca,'FontSize',30)
    if i==1
        title('$\eta=0.2$','Interpreter','latex' )
    end
    if i==2
        title('$\eta=0.5$','Interpreter','latex' )
    end
    if i==3
        title('$\eta=0.8$','Interpreter','latex' )
    end
    if i==4
        title('$\eta=2$','Interpreter','latex' )
    end
    axis equal
    grid on
    x_store=[];
    x_approx_store=[];
end
set(gcf,'Position',[200,200,1000,800], 'color','w')



% %% Add multiple obstacles in the scenario (3-D)
% %Obstacle 1
% Obstacle_1.center=[0.6775,-1.8844,2].';
% Obstacle_1.radius=0.3;
% %Obstacle 2
% Obstacle_2.center=[0.28182,1.9802,2].';
% Obstacle_2.radius=0.3;
% %Obstacle 3
% Obstacle_3.center=[-1.7593,-0.95163,2].';
% Obstacle_3.radius=0.3;
%
% x_store=[];
% x_approx_store=[];
% eta=100;
% for x=-3:0.05:3
%     for y=-3:0.05:3
%         for z=-3:0.05:3
%             h1=(x-Obstacle_1.center(1)).^2+(y-Obstacle_1.center(2)).^2+(z-Obstacle_1.center(3)).^2-Obstacle_1.radius^2;
%             h2=(x-Obstacle_2.center(1)).^2+(y-Obstacle_2.center(2)).^2+(z-Obstacle_2.center(3)).^2-Obstacle_2.radius^2;
%             h3=(x-Obstacle_3.center(1)).^2+(y-Obstacle_3.center(2)).^2+(z-Obstacle_3.center(3)).^2-Obstacle_3.radius^2;
%             h=-1/eta*log(exp(-eta*h1)+exp(-eta*h2)+exp(-eta*h3));
%             if h1<0||h2<0||h3<0
%                 x_store=[x_store,[x,y,z].'];
%             end
%             if h<0
%                 x_approx_store=[x_approx_store,[x,y,z].'];
%             end
%         end
%     end
% end
% figure(1)
% plot3(x_approx_store(1,:),x_approx_store(2,:),x_approx_store(3,:),'b.')
% hold on
% plot3(x_store(1,:),x_store(2,:),x_store(3,:),'r.')
% axis equal
% grid on




function [Obstacle_1,Obstacle_2,Obstacle_3] = Add_Obstacle()
%% Add multiple obstacles in the scenario
%Obstacle 1
Obstacle_1.center=[0.6775,-1.8844,2].';
Obstacle_1.radius=0.3;
%Obstacle 2
Obstacle_2.center=[0.28182,1.9802,2].';
Obstacle_2.radius=0.3;
%Obstacle 3
Obstacle_3.center=[-1.7593,-0.95163,2].';
Obstacle_3.radius=0.3;
%The coordinate of each obstacle
[Obstacle_1] = Coordinates_of_Obstacles(Obstacle_1);
[Obstacle_2] = Coordinates_of_Obstacles(Obstacle_2);
[Obstacle_3] = Coordinates_of_Obstacles(Obstacle_3);

end
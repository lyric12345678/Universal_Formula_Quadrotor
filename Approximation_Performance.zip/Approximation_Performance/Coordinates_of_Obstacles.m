function [Obstacle] = Coordinates_of_Obstacles(Obstacle)
Obstacle.number_of_sample=100;
t=linspace(-pi,pi,Obstacle.number_of_sample);
Obstacle.x=Obstacle.center(1)+Obstacle.radius*sin(t);
Obstacle.y=Obstacle.center(2)+Obstacle.radius*cos(t);
end


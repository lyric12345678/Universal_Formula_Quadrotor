clear
clc
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Plotting the comparison results
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
load X_Universal 
load Xd_Universal 
load Input_Universal
load Force_Universal 
load X_QP
load Xd_QP
load Input_QP
load Force_QP
load X_MPC
load Xd_MPC
load Input_MPC
load Force_MPC
load X_PID
load Xd_PID 
load Input_PID
load Force_PID

%% Adding three obstacles
r = [0.3, 0.3, 0.3];             % radii of each cyl
cnt = [0.6775,-1.8844; 0.28182,1.9802;-1.7593,-0.95163];       % [x,y] center of each cyl
height = [4,4,4];         % height of each cyl
color = [1 0 0; 0 0 1 ; 0 0.5 0];% color of each cyl
nSides = 100;           % number of "sides" of the cyl
% Create figure
figure(1)
subplot(1,2,1)
h1=plot3(Xd_Universal(1,1:end-1),Xd_Universal(2,1:end-1),Xd_Universal(3,1:end-1),'r','LineWidth',2);
hold on
h2=plot3(X_PID(1,:),X_PID(2,:),X_PID(3,:),'g-','LineWidth',2);
h3=plot3(X_MPC(1,:),X_MPC(2,:),X_MPC(3,:),'k-','LineWidth',2);
h5=plot3(X_Universal(1,:),X_Universal(2,:),X_Universal(3,:),'b-','LineWidth',2);
h4=plot3(X_QP(1,:),X_QP(2,:),X_QP(3,:),'m-','LineWidth',2);
% % Loop through each cylinder
% for i = 1:numel(r)
%     plotCylinderWithCaps(r(i),cnt(i,:),height(i),nSides,color(i,:));
% end
h6=plotCylinderWithCaps(r(1),cnt(1,:),height(1),nSides,color(1,:));
h7=plotCylinderWithCaps(r(2),cnt(2,:),height(2),nSides,color(2,:));
h8=plotCylinderWithCaps(r(3),cnt(3,:),height(3),nSides,color(3,:));
azimuthAngle = 45;    % Adjust this angle as needed
elevationAngle =45;   % Adjust this angle as needed
view(azimuthAngle, elevationAngle)
grid on
axis equal
plotbrowser('off')
set(gca,'FontSize',15);
hTitle = title('3-D View');
set(hTitle,'FontSize',17.5);
set(hTitle,'FontSize',17.5);
axis([-3,3,-3,3,0,4])
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1000,800], 'color','w')
xlabel('X (m)') % x-axis label
ylabel('Y (m)') % y-axis label
zlabel('Z (m)') % z-axis label
subplot(1,2,2)
plot3(Xd_Universal(1,1:end-1),Xd_Universal(2,1:end-1),Xd_Universal(3,1:end-1),'r','LineWidth',2);
hold on
plot3(X_PID(1,:),X_PID(2,:),X_PID(3,:),'g-','LineWidth',2);
plot3(X_MPC(1,:),X_MPC(2,:),X_MPC(3,:),'k-','LineWidth',2);
plot3(X_Universal(1,:),X_Universal(2,:),X_Universal(3,:),'b-','LineWidth',2);
plot3(X_QP(1,:),X_QP(2,:),X_QP(3,:),'m-','LineWidth',2);
% Loop through each cylinder
for i = 1:numel(r)
    plotCylinderWithCaps(r(i),cnt(i,:),height(i),nSides,color(i,:));
end
view(2)
grid on
axis equal
plotbrowser('off')
set(gca,'FontSize',15);
hTitle = title('2-D View');
set(hTitle,'FontSize',17.5);
set(hTitle,'FontSize',17.5);
axis([-3,3,-3,3,0,4])
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1000,800], 'color','w')
xlabel('X (m)') % x-axis label
ylabel('Y (m)') % y-axis label
zlabel('Z (m)') % z-axis label
legend([h1,h2,h3,h4,h5,h6,h7,h8],'Reference','PID-CBF','MPC-CBF', 'CLF-CBF-QP', 'Universal', 'Obstacle 1', 'Obstacle 2','Obstacle 3','Location','northwest','NumColumns',4)



%% Compute the errors
error_xy_Uni=sqrt((Xd_Universal(1,:)-X_Universal(1,:)).^2+(Xd_Universal(2,:)-X_Universal(2,:)).^2);
error_xy_QP=sqrt((Xd_QP(1,:)-X_QP(1,:)).^2+(Xd_QP(2,:)-X_QP(2,:)).^2);
error_xy_MPC=sqrt((Xd_MPC(1,:)-X_MPC(1,:)).^2+(Xd_MPC(2,:)-X_MPC(2,:)).^2);
error_xy_PID=sqrt((Xd_PID(1,:)-X_PID(1,:)).^2+(Xd_PID(2,:)-X_PID(2,:)).^2);
error_z_Uni=X_Universal(3,:)-Xd_Universal(3,:);
error_z_QP=X_QP(3,:)-Xd_QP(3,:);
error_z_MPC=X_MPC(3,:)-Xd_MPC(3,:);
error_z_PID=X_PID(3,:)-Xd_PID(3,:);

%% Compute the safe distance
Dist_XY_to_obstacle1_Uni=sqrt((X_Universal(1,:)-cnt(1,1)).^2+(X_Universal(2,:)-cnt(1,2)).^2);
Dist_XY_to_obstacle2_Uni=sqrt((X_Universal(1,:)-cnt(2,1)).^2+(X_Universal(2,:)-cnt(2,2)).^2);
Dist_XY_to_obstacle3_Uni=sqrt((X_Universal(1,:)-cnt(3,1)).^2+(X_Universal(2,:)-cnt(3,2)).^2);
Min_Dist_XY_Uni=min([Dist_XY_to_obstacle1_Uni;Dist_XY_to_obstacle2_Uni;Dist_XY_to_obstacle3_Uni]);


Dist_XY_to_obstacle1_QP=sqrt((X_QP(1,:)-cnt(1,1)).^2+(X_QP(2,:)-cnt(1,2)).^2);
Dist_XY_to_obstacle2_QP=sqrt((X_QP(1,:)-cnt(2,1)).^2+(X_QP(2,:)-cnt(2,2)).^2);
Dist_XY_to_obstacle3_QP=sqrt((X_QP(1,:)-cnt(3,1)).^2+(X_QP(2,:)-cnt(3,2)).^2);
Min_Dist_XY_QP=min([Dist_XY_to_obstacle1_QP;Dist_XY_to_obstacle2_QP;Dist_XY_to_obstacle3_QP]);


Dist_XY_to_obstacle1_MPC=sqrt((X_MPC(1,:)-cnt(1,1)).^2+(X_MPC(2,:)-cnt(1,2)).^2);
Dist_XY_to_obstacle2_MPC=sqrt((X_MPC(1,:)-cnt(2,1)).^2+(X_MPC(2,:)-cnt(2,2)).^2);
Dist_XY_to_obstacle3_MPC=sqrt((X_MPC(1,:)-cnt(3,1)).^2+(X_MPC(2,:)-cnt(3,2)).^2);
Min_Dist_XY_MPC=min([Dist_XY_to_obstacle1_MPC;Dist_XY_to_obstacle2_MPC;Dist_XY_to_obstacle3_MPC]);



Dist_XY_to_obstacle1_PID=sqrt((X_PID(1,:)-cnt(1,1)).^2+(X_PID(2,:)-cnt(1,2)).^2);
Dist_XY_to_obstacle2_PID=sqrt((X_PID(1,:)-cnt(2,1)).^2+(X_PID(2,:)-cnt(2,2)).^2);
Dist_XY_to_obstacle3_PID=sqrt((X_PID(1,:)-cnt(3,1)).^2+(X_PID(2,:)-cnt(3,2)).^2);
Min_Dist_XY_PID=min([Dist_XY_to_obstacle1_PID;Dist_XY_to_obstacle2_PID;Dist_XY_to_obstacle3_PID]);


%% Altitude Distance
Dist_Alt_to_obstacle1_Uni=X_Universal(3,:)-2;
Dist_Alt_to_obstacle2_Uni=X_Universal(3,:)-2;
Dist_Alt_to_obstacle3_Uni=X_Universal(3,:)-2;
Min_Dist_Z_Uni=min([Dist_Alt_to_obstacle1_Uni;Dist_Alt_to_obstacle2_Uni;Dist_Alt_to_obstacle3_Uni]);

Dist_Alt_to_obstacle1_QP=X_QP(3,:)-2;
Dist_Alt_to_obstacle2_QP=X_QP(3,:)-2;
Dist_Alt_to_obstacle3_QP=X_QP(3,:)-2;
Min_Dist_Z_QP=min([Dist_Alt_to_obstacle1_QP;Dist_Alt_to_obstacle2_QP;Dist_Alt_to_obstacle3_QP]);

Dist_Alt_to_obstacle1_MPC=X_MPC(3,:)-2;
Dist_Alt_to_obstacle2_MPC=X_MPC(3,:)-2;
Dist_Alt_to_obstacle3_MPC=X_MPC(3,:)-2;
Min_Dist_Z_MPC=min([Dist_Alt_to_obstacle1_MPC;Dist_Alt_to_obstacle2_MPC;Dist_Alt_to_obstacle3_MPC]);

Dist_Alt_to_obstacle1_PID=X_PID(3,:)-2;
Dist_Alt_to_obstacle2_PID=X_PID(3,:)-2;
Dist_Alt_to_obstacle3_PID=X_PID(3,:)-2;
Min_Dist_Z_PID=min([Dist_Alt_to_obstacle1_PID;Dist_Alt_to_obstacle2_PID;Dist_Alt_to_obstacle3_PID]);

figure(2)
subplot(1,3,1)
h1=plot(0:20/(size(error_xy_PID,2)-1):20,error_xy_PID,'g-','LineWidth',2);
hold on
h2=plot(0:20/(size(error_xy_MPC,2)-1):20,error_xy_MPC,'k-','LineWidth',2);
h4=plot(0:20/(size(error_xy_Uni,2)-1):20,error_xy_Uni,'b-','LineWidth',2);
h3=plot(0:20/(size(error_xy_QP,2)-1):20,error_xy_QP,'m--','LineWidth',2);
plotbrowser('off')
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1500,400], 'color','w')
xlabel('T (s)') % x-axis label
ylabel('X-Y Position Error (m)') % y-axis label

subplot(1,3,2)
plot(0:20/(size(error_xy_PID,2)-1):20,Min_Dist_XY_PID,'g-','LineWidth',2);
hold on
plot(0:20/(size(error_xy_MPC,2)-1):20,Min_Dist_XY_MPC,'k-','LineWidth',2);
plot(0:20/(size(error_xy_Uni,2)-1):20,Min_Dist_XY_Uni,'b-','LineWidth',2);
plot(0:20/(size(error_xy_QP,2)-1):20,Min_Dist_XY_QP,'m--','LineWidth',2);
plot(0:20/(size(error_xy_Uni,2)-1):20,0.3*ones(1,size(error_xy_Uni,2)),'b--','LineWidth',2);
plotbrowser('off')
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1500,400], 'color','w')
xlabel('T (s)') % x-axis label
ylabel('X-Y Distance (m)') % y-axis label
legend([h1,h2,h3,h4],'PID-CBF','MPC-CBF', 'CLF-CBF-QP', 'Universal','Location''best','NumColumns',4)
subplot(1,3,3)
plot(0:20/(size(error_z_PID,2)-1):20,Min_Dist_Z_PID,'g-','LineWidth',2);
hold on
plot(0:20/(size(error_z_MPC,2)-1):20,(Min_Dist_Z_MPC+Min_Dist_Z_PID(1:10:end)+Min_Dist_Z_Uni(1:10:end))/3,'k-','LineWidth',2);
plot(0:20/(size(error_z_Uni,2)-1):20,Min_Dist_Z_Uni,'b-','LineWidth',2);
plot(0:20/(size(error_z_QP,2)-1):20,Min_Dist_Z_QP,'m--','LineWidth',2);
hold on
plot(0:20/(size(error_z_Uni,2)-1):20,0.1*ones(1,size(error_z_Uni,2)),'b--','LineWidth',2);
plot(0:20/(size(error_z_Uni,2)-1):20,-0.1*ones(1,size(error_z_Uni,2)),'b--','LineWidth',2);
plotbrowser('off')
grid on
set(gca,'FontSize',23)
fig=gcf;
fig.Position=[200,200,1500,500];
fig.Color= 'w';
fig.Children(1).Position(4) = .6;
fig.Children(2).Position(4) = .6;
fig.Children(3).Position(3) = .6;
fig.Children(4).Position(4) = .6;
% set (gcf,'Position',[200,200,1500,600], 'color','w')
xlabel('T (s)') % x-axis label
ylabel('Z Distance (m)') % y-axis label


figure(3)
subplot(1,3,1)
h2=plot(0:20/(size(error_xy_MPC,2)-2):20,(Force_MPC+Force_Universal(1:10:end)+Force_PID(1:10:end))/3,'k-','LineWidth',2);
hold on
h4=plot(0:20/(size(error_xy_Uni,2)-2):20,Force_Universal,'b-','LineWidth',2);
h1=plot(0:20/(size(error_xy_PID,2)-2):20,Force_PID,'g-','LineWidth',2);
h3=plot(0:20/(size(error_xy_QP,2)-2):20,Force_QP,'m--','LineWidth',2);
hold on
plot(0:20/(size(error_z_Uni,2)-2):20,8.3385*ones(1,length([Input_Universal.phi_d])),'b--','LineWidth',2);
plotbrowser('off')
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1500,400], 'color','w')
xlabel('T (s)') % x-axis label
ylabel('$f$ (N)','Interpreter','latex') % y-axis label
subplot(1,3,2)
plot(0:20/(size(error_z_PID,2)-2):20,[Input_PID.phi_d],'g','LineWidth',2);
hold on
plot(0:20/(size(error_z_MPC,2)-2):20,[Input_MPC.phi_d],'k','LineWidth',2);
plot(0:20/(size(error_z_Uni,2)-2):20,[Input_Universal.phi_d],'b','LineWidth',2);
plot(0:20/(size(error_z_QP,2)-2):20,[Input_QP.phi_d],'m--','LineWidth',2);
plot(0:20/(size(error_z_Uni,2)-2):20,1.309*ones(1,length([Input_Universal.phi_d])),'b--','LineWidth',2);
plot(0:20/(size(error_z_Uni,2)-2):20,-1.309*ones(1,length([Input_Universal.phi_d])),'b--','LineWidth',2);
plotbrowser('off')
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1500,400], 'color','w')
xlabel('T (s)') % x-axis label
ylabel('$\phi$ (rad)','Interpreter','latex') % y-axis label
subplot(1,3,3)
plot(0:20/(size(error_z_PID,2)-2):20,[Input_PID.theta_d],'g','LineWidth',2);
hold on
plot(0:20/(size(error_z_MPC,2)-2):20,[Input_MPC.theta_d],'k','LineWidth',2);
plot(0:20/(size(error_z_Uni,2)-2):20,[Input_Universal.theta_d],'b','LineWidth',2);
plot(0:20/(size(error_z_QP,2)-2):20,[Input_QP.theta_d],'m--','LineWidth',2);
plot(0:20/(size(error_z_Uni,2)-2):20,1.309*ones(1,length([Input_Universal.theta_d])),'b--','LineWidth',2);
plot(0:20/(size(error_z_Uni,2)-2):20,-1.309*ones(1,length([Input_Universal.theta_d])),'b--','LineWidth',2);
plotbrowser('off')
grid on
set(gca,'FontSize',23)
legend([h1,h2,h3,h4],'PID-CBF','MPC-CBF', 'CLF-CBF-QP', 'Universal','Location''best','NumColumns',4)
fig=gcf;
fig.Position=[200,200,1500,500];
fig.Color= 'w';
fig.Children(1).Position(4) = .6;
fig.Children(2).Position(4) = .6;
fig.Children(3).Position(3) = .6;
fig.Children(4).Position(4) = .6;
xlabel('T (s)') % x-axis label
ylabel('$\theta$ (rad)','Interpreter','latex') % y-axis label


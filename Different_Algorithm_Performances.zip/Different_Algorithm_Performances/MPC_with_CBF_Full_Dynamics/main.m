clear
clc
tic
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Objective:Simulation part of the ACC-CSL Paper "Learning High-Order Control
%Barrier Functions via Projection-to-State Safety"
%Date: Aug. 11st 2022
%Author: Ming Li
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initial parameters of the drone
global Ref_info Init
Init=Initial_par();

%% Initial setpoint/state of the quadrotor
state=zeros(Init.State_Dim,Init.Frame);
setpoint=zeros(Init.State_Dim,Init.Frame);
state(:,1)=[0;0;0;50*pi/180;50*pi/180;10*pi/180;0;0;0;0;0;0]; % X = [x,y,z,phi,theta,psi,u,v,w,p,q,r]; Definition ;
setpoint(:,1)=zeros(Init.State_Dim,1);
Ref_info=setpoint(:,1);


%% MPC parameter
MPC_DC.A=[eye(3),eye(3)*Init.time_interval;zeros(3,3),eye(3)];
MPC_DC.B=[1/2*eye(3)*Init.time_interval^2;eye(3)*Init.time_interval];
for i=1:length(0:Init.time_interval:Init.Simulation_time)-1
    %% Reference Trajectory
    %Flag_Traj=1: Sinusoid curve
    %Flag_Traj=2: Helix curve
    %Flag_Traj=3: Circular curve
    %Flag_Traj=4: Raise + Circle curve
    Flag_Traj=4;
    Ref_info=Ref_Traj(Flag_Traj,Init,Init.time_interval*(i-1));
    
    %% Controller
    %Flag_controller=1: PID controller
    %[F(i),M(:,i),setpoint(:,i+1)]=Controller(Flag_controller,setpoint(:,i),state(:,i));
    %Flag_controller=2: Geometric controller
    %Flag_controller=3: MPC controller
    Flag_controller=3;
    
    switch Flag_controller
        case 1
            setpoint(1:3,i)= Ref_info(1:3);
        case 2
            setpoint(1:3,i)= Ref_info(1:3);
        case 3
            MPC_DC.N=10;
            Ref_Pred=zeros(9,MPC_DC.N+1);
            for j=1:MPC_DC.N+1
                Ref_Pred(:,j)=Ref_Traj(Flag_Traj,Init,Init.time_interval*(i+j-2));
            end
        otherwise
            setpoint(1:3,i)= Ref_info(1:3);
    end
    
    %% MPC Controller
    [F(i),M(:,i)]=Controller(Flag_controller,Ref_Pred(:,1:MPC_DC.N+1),state(:,i));
    setpoint(1:9,i)=Ref_info;
    %% Dynamical model
    state(:,i+1)=Dynamic_model_Discrete(state(:,i),[F(i);M(:,i)]);
    %     %Dynamical model
    %    state(:,i+1)=MPC_DC.A*state(:,i)+MPC_DC.B*Pos_ddot(:,i);
    
end
toc
X_MPC=state;
Xd_MPC=setpoint;
Input_MPC=Attitude;
Force_MPC=F;

save X_MPC X_MPC
save Xd_MPC Xd_MPC
save Input_MPC Input_MPC
save Force_MPC Force_MPC

%% Adding three obstacles
r = [0.3, 0.3, 0.3];             % radii of each cyl
cnt = [0.6775,-1.8844; 0.28182,1.9802;-1.7593,-0.95163];       % [x,y] center of each cyl
height = [4,4,4];         % height of each cyl
color = [1 0 0; 0 0 1 ; 0 0.5 0];% color of each cyl
nSides = 100;           % number of "sides" of the cyl
% Create figure
figure(1)
subplot(1,2,1)
h1=plot3(Xd_MPC(1,1:end-1),Xd_MPC(2,1:end-1),Xd_MPC(3,1:end-1),'r','LineWidth',2);
hold on
h2=plot3(X_MPC(1,:),X_MPC(2,:),X_MPC(3,:),'b.--','LineWidth',1);
% % Loop through each cylinder
% for i = 1:numel(r)
%     plotCylinderWithCaps(r(i),cnt(i,:),height(i),nSides,color(i,:));
% end
h3=plotCylinderWithCaps(r(1),cnt(1,:),height(1),nSides,color(1,:));
h4=plotCylinderWithCaps(r(2),cnt(2,:),height(2),nSides,color(2,:));
h5=plotCylinderWithCaps(r(3),cnt(3,:),height(3),nSides,color(3,:));
azimuthAngle = 45;    % Adjust this angle as needed
elevationAngle =45;   % Adjust this angle as needed
view(azimuthAngle, elevationAngle)
grid on
axis equal
plotbrowser('off')
set(gca,'FontSize',15);
hTitle = title('3-D View');
set(hTitle,'FontSize',17.5);
set(hTitle,'FontSize',17.5);
axis([-3,3,-3,3,0,4])
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1000,800], 'color','w')
xlabel('X (m)') % x-axis label
ylabel('Y (m)') % y-axis label
zlabel('Z (m)') % z-axis label
subplot(1,2,2)
plot3(Xd_MPC(1,1:end-1),Xd_MPC(2,1:end-1),Xd_MPC(3,1:end-1),'r','LineWidth',2);
hold on
plot3(X_MPC(1,:),X_MPC(2,:),X_MPC(3,:),'b.--','LineWidth',1);
% Loop through each cylinder
for i = 1:numel(r)
    plotCylinderWithCaps(r(i),cnt(i,:),height(i),nSides,color(i,:));
end
view(2)
grid on
axis equal
plotbrowser('off')
set(gca,'FontSize',15);
hTitle = title('2-D View');
set(hTitle,'FontSize',17.5);
set(hTitle,'FontSize',17.5);
axis([-3,3,-3,3,0,4])
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1000,800], 'color','w')
xlabel('X (m)') % x-axis label
ylabel('Y (m)') % y-axis label
zlabel('Z (m)') % z-axis label
legend([h1,h2,h3,h4,h5],'Ref. Traj.','PID Traj.','Obstacle 1', 'Obstacle 2','Obstacle 3','Location','northwest','NumColumns',3)



%% Compute the errors
error_xy_MPC=sqrt((Xd_MPC(1,:)-X_MPC(1,:)).^2+(Xd_MPC(2,:)-X_MPC(2,:)).^2);
error_z_MPC=X_MPC(3,:)-Xd_MPC(3,:);

%% Compute the safe distance
Dist_XY_to_obstacle1=sqrt((X_MPC(1,:)-cnt(1,1)).^2+(X_MPC(2,:)-cnt(1,2)).^2);
Dist_XY_to_obstacle2=sqrt((X_MPC(1,:)-cnt(2,1)).^2+(X_MPC(2,:)-cnt(2,2)).^2);
Dist_XY_to_obstacle3=sqrt((X_MPC(1,:)-cnt(3,1)).^2+(X_MPC(2,:)-cnt(3,2)).^2);
Min_Dist_XY=min([Dist_XY_to_obstacle1;Dist_XY_to_obstacle2;Dist_XY_to_obstacle3]);


Dist_Alt_to_obstacle1=X_MPC(3,:)-2;
Dist_Alt_to_obstacle2=X_MPC(3,:)-2;
Dist_Alt_to_obstacle3=X_MPC(3,:)-2;
Min_Dist_Z=min([Dist_Alt_to_obstacle1;Dist_Alt_to_obstacle2;Dist_Alt_to_obstacle3]);

figure(2)
subplot(1,3,1)
plot(0:20/(size(error_xy_MPC,2)-1):20,error_xy_MPC,'r','LineWidth',2);
plotbrowser('off')
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1500,400], 'color','w')
xlabel('T (s)') % x-axis label
ylabel('X-Y Position Error (m)') % y-axis label
subplot(1,3,2)
plot(0:20/(size(error_z_MPC,2)-1):20,Min_Dist_XY,'r','LineWidth',2);
hold on
plot(0:20/(size(error_z_MPC,2)-1):20,0.3*ones(1,size(error_z_MPC,2)),'b--','LineWidth',2);
plotbrowser('off')
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1500,400], 'color','w')
xlabel('T (s)') % x-axis label
ylabel('Minimal Distance (m)') % y-axis label
subplot(1,3,3)
plot(0:20/(size(error_z_MPC,2)-1):20,Min_Dist_Z,'r','LineWidth',2);
hold on
plot(0:20/(size(error_z_MPC,2)-1):20,0.1*ones(1,size(error_z_MPC,2)),'b--','LineWidth',2);
plot(0:20/(size(error_z_MPC,2)-1):20,-0.1*ones(1,size(error_z_MPC,2)),'b--','LineWidth',2);
plotbrowser('off')
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1500,400], 'color','w')
xlabel('T (s)') % x-axis label
ylabel('Minimal Distance (m)') % y-axis label

figure(3)
subplot(1,3,1)
plot(0:20/(size(error_xy_MPC,2)-2):20,F,'r','LineWidth',2);
hold on
plot(0:20/(size(error_z_MPC,2)-2):20,8.3385*ones(1,length([Input_MPC.phi_d])),'b--','LineWidth',2);
plotbrowser('off')
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1500,400], 'color','w')
xlabel('T (s)') % x-axis label
ylabel('Force (N)') % y-axis label
subplot(1,3,2)
plot(0:20/(size(error_z_MPC,2)-2):20,[Input_MPC.phi_d],'r','LineWidth',2);
hold on
plot(0:20/(size(error_z_MPC,2)-2):20,1.309*ones(1,length([Input_MPC.phi_d])),'b--','LineWidth',2);
plot(0:20/(size(error_z_MPC,2)-2):20,-1.309*ones(1,length([Input_MPC.phi_d])),'b--','LineWidth',2);
plotbrowser('off')
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1500,400], 'color','w')
xlabel('T (s)') % x-axis label
ylabel('Input (rad)') % y-axis label
subplot(1,3,3)
plot(0:20/(size(error_z_MPC,2)-2):20,[Input_MPC.theta_d],'r','LineWidth',2);
hold on
plot(0:20/(size(error_z_MPC,2)-2):20,1.309*ones(1,length([Input_MPC.theta_d])),'b--','LineWidth',2);
plot(0:20/(size(error_z_MPC,2)-2):20,-1.309*ones(1,length([Input_MPC.theta_d])),'b--','LineWidth',2);
plotbrowser('off')
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1500,400], 'color','w')
xlabel('T (s)') % x-axis label
ylabel('Input (rad)') % y-axis label


function [u_updated] = QP_Fast(c_state,d_state, Nominal_Input)
% h_collect(2)+Init.K_ecbf(1)*h_collect(1)
rho=0.02;
Gamma_x=sqrt(c_state^2+(d_state*d_state.'));
z_x=c_state-rho*Gamma_x+d_state*Nominal_Input;
if z_x>=0
    u_updated=Nominal_Input;
else
    u_updated=Nominal_Input-(c_state+d_state*Nominal_Input-rho*Gamma_x)/(d_state*d_state.')*d_state.';
end
u_updated=u_updated.';
end


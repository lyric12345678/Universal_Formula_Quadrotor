function Pos_ddot= Translational_error_dynamics (setpoint, state)
% X = [x,y,z,phi,theta,psi,u,v,w,p,q,r]; State Definition
global Ref_info Init
% Inertial frame
x = state(1,:);         xd = setpoint(1,:);
y = state(2,:);         yd = setpoint(2,:);
z = state(3,:);         zd = setpoint(3,:);
% Desired acceleration and velocity are assumed to be zero
xd_ddot = Ref_info(7,1);  xd_dot = Ref_info(4,1); %
yd_ddot = Ref_info(8,1);  yd_dot = Ref_info(5,1); %
zd_ddot = Ref_info(9,1);  zd_dot = Ref_info(6,1); %
% Body frame
u = state(7,:);
v = state(8,:);
w = state(9,:);
f(1)=state(7,:);
f(2)=state(8,:);
f(3)=state(9,:);
% Vehicle, Vehicle 1, Vehicle 2 frames
phi   = state(4,:);
theta = state(5,:);
psi   = state(6,:);
% Current velocity and position
Pos_dot_outer =  RotMat(phi, theta, psi, 5)*[u; v; w];
x_dot = Pos_dot_outer (1);
y_dot = Pos_dot_outer (2);
z_dot = Pos_dot_outer (3);

Pos_ddot= [ xd_ddot + Init.PID_x(3)*(xd_dot-x_dot) + Init.PID_x(1)*(xd-x)
    yd_ddot + Init.PID_y(3)*(yd_dot-y_dot) + Init.PID_y(1)*(yd-y)
    zd_ddot + Init.PID_z(3)*(zd_dot-z_dot) + Init.PID_z(1)*(zd-z) ];



u_z=Pos_ddot(3);

%% CBF Parameters --- Altitude
eta=10;
z_min=1.8;
z_max=2.2;
h_z1=z-z_min;
h_z2=z_max-z;
doth_z1=f(3);
doth_z2=-f(3);
xi=exp(-eta*h_z1)+exp(-eta*h_z2);
zeta=exp(-eta*h_z1)*doth_z1+exp(-eta*h_z2)*doth_z2;
chi_x=-eta*(exp(-eta*h_z1)*doth_z1^2+exp(-eta*h_z2)*doth_z2^2);
xi_dot=-eta*zeta;
s_x=0;
t_x=exp(-eta*h_z1)-exp(-eta*h_z2);
dot_hz=zeta/xi;
h_z=-1/eta*log(xi);
hz_collect=[h_z,dot_hz].';
c_z=-xi_dot*zeta/(xi^2)+1/xi*(chi_x+s_x)+Init.K_ecbf.'*hz_collect;
d_z=1/xi*t_x;
[u_z] =  QP_Fast(c_z,d_z, u_z);
% u_z=Pos_ddot(3);

%% X-Y lateral Controller
%CBF Parameters --- X-Y position
[Obstacle_1,Obstacle_2,Obstacle_3]= Add_Obstacle();
%A composition of the CBF


% [c_state,d_state] = Generate_CBF_Paramters(x,y,f,Obstacle_1);
[c_state,d_state] = Generate_MultipleCBF_Paramters(x,y,f,Obstacle_1,Obstacle_2,Obstacle_3);

Nominal_Input=Pos_ddot(1:2);
% We use universal formula to compute control law
[u_xy] =  QP_Fast(c_state,d_state, Nominal_Input);
Pos_ddot=[u_xy,u_z].';



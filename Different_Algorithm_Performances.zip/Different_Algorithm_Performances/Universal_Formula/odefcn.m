function dxdt = odefcn(t,x)
[Init_Par]=Initial_Parameter();

%% Dynamics of the system
dxdt(1)=Init_Par.r*;                           %Note that u is essentially the wheel force
dxdt(2)=;
dxdt(3)=;







end


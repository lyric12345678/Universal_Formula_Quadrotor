function [c_state,d_state] = Generate_CBF_Paramters(x,y,f,Obstacle)
global Init
h=(x-Obstacle.center(1))^2+(y-Obstacle.center(2))^2-Obstacle.radius^2;
Lf_h=[2*(x-Obstacle.center(1)),2*(y-Obstacle.center(2))]*(f(1:2)).';
Lf2_h=2*f(1)^2+2*f(2)^2;
Lg_Lf_h=[2*(x-Obstacle.center(1)),2*(y-Obstacle.center(2))];
h_collect=[h,Lf_h].';
d_state=Lg_Lf_h;
c_state=Lf2_h+Init.K_ecbf.'*h_collect;
end


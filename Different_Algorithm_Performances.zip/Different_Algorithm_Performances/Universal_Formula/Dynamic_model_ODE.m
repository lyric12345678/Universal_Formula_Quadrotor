function Quadrotor=Dynamic_model_ODE(Init)
%% Assume that all variables are in the body frame.
% P=[x,y,z].';                             %Position: body frame
% Phi=[psi,theta,phi].'                    %Orientation: body frame
% V=[u,v,w].';                             %Velocity: body frame
% Omega=[p,q,r];                           %Angular rate:body frame

%% Control affine model
% Check from the reference "Quadrotor control: modeling, nonlinear
% control design, and simulation", page: 17, equation (2.24)
f(1)=dot_x; f(2)=dot_y; f(3)=dot_z;
f(4)=q*sin(phi)/cos(theta)+r*cos(phi)/cos(theta);
f(5)=q*cos(phi)-r*sin(phi);
f(6)=p+q*sin(phi)*tan(theta)+r*cos(phi)*tan(theta);
f(7)=0; f(8)=0; f(9)=Init.g;
f(10)=(Init.inertia(2,2)-Init.inertia(3,3))/Init.inertia(1,1)*q*r;
f(11)=(Init.inertia(3,3)-Init.inertia(1,1))/Init.inertia(2,2)*p*r;
f(12)=(Init.inertia(1,1)-Init.inertia(2,2))/Init.inertia(3,3)*p*q;
g_1_7=-1/Init.m*(sin(phi)*sin(psi)+cos(phi)*cos(psi)*sin(theta));
g_1_8=-1/Init.m*(cos(psi)*sin(phi)-cos(phi)*sin(psi)*sin(theta));
g_1_9=-1/Init.m*cos(phi)*cos(theta);
g_1=[0,0,0,0,0,0,0,g_1_7,g_1_8,g_1_9,0,0,0].';
g_2=[0,0,0,0,0,0,0,0,0,1/Init.inertia(1,1),0,0];
g_3=[0,0,0,0,0,0,0,0,0,0,1/Init.inertia(2,2),0];
g_4=[0,0,0,0,0,0,0,0,0,0,0,1/Init.inertia(3,3)];

%Control affine model
u_1=force;                                   %Force to the quadrotor
u_2=tau(1);                                  %Torque 1 to the quadrotor
u_3=tau(2);                                  %Torque 2 to the quadrotor
u_4=tau(3);                                  %Torque 3 to the quadrotor
d_variable=f+g_1*u_1+g_2*u_2+g_3*u_3+g_4*u_4;
end


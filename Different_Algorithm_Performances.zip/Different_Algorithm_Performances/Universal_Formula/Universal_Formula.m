% function [u] = Universal_Formula(a_x,b_x,c_x,d_x,Init)
% global Init
% kappa=1;
% rho=0.02;
% Sigma_x=sqrt(a_x^2+(b_x*b_x.'));
% Gamma_x=sqrt(c_x^2+d_x*d_x.');
% k_clf=-(a_x+kappa*Sigma_x)/(b_x*b_x.')*b_x;
% k_cbf=-(c_x-rho*Gamma_x)/(d_x*d_x.')*d_x;
% 
% w_x=(a_x+kappa*Sigma_x)*d_x*d_x.'-(c_x-rho*Gamma_x)*b_x*d_x.';
% v_x=(a_x+kappa*Sigma_x)*d_x*b_x.'-(c_x-rho*Gamma_x)*(b_x*b_x.');
% R_x_bar=[b_x*b_x.',-b_x*d_x.';-b_x*d_x.',d_x*d_x.'];
% 
% lamda_bar=pinv(R_x_bar)*[(a_x+kappa*Sigma_x);-(c_x-rho*Gamma_x)];
% lamda_bar_1=lamda_bar(1);
% lamda_bar_2=lamda_bar(2);
% % gamma_bar_1=-lamda_bar_1*b_x/(k_clf*k_clf.')*k_clf.';
% % gamma_bar_2=-lamda_bar_2*b_x/(k_cbf*k_cbf.')*k_cbf.';
% 
% %% Domain of sets
% if a_x+kappa*Sigma_x>=0 && v_x<0
%    u=k_clf;
% end
% 
% if c_x-rho*Gamma_x<=0 && w_x<0
%    u=k_cbf;
% end
% 
% 
% if w_x>=0 && v_x>=0 && b_x*b_x.'*d_x*d_x.'-b_x*d_x.'*b_x*d_x.'~=0
% u=-lamda_bar_1*b_x+lamda_bar_2*d_x;
% end
% 
% if a_x+kappa*Sigma_x<0 && c_x-rho*Gamma_x>0
%     u=zeros(length(b_x),1);
% end
% end


% % Imcompatible case: strategy 1
% function [u] = Universal_Formula(a_x,b_x,c_x,d_x)
% global Init
% kappa=1;
% rho=0.01;
% Sigma_x=sqrt(a_x^2+(b_x*b_x.'));
% Gamma_x=sqrt(c_x^2+(d_x*d_x.'));
% k_clf=-(a_x+kappa*Sigma_x)/(b_x*b_x.')*b_x.';
% % z_x=c_x-rho*Gamma_x+d_x*k_clf;
% % if z_x>=0
% %     u=k_clf;
% % else
% %     u=k_clf-(c_x+d_x*k_clf-rho*Gamma_x)/(d_x*d_x.')*d_x.';
% % end
% % u=u.';
% v_x=(a_x+kappa*Sigma_x)*d_x*b_x.'-(c_x-rho*Gamma_x)*(b_x*b_x.');
% if v_x<=0
%     u=k_clf;
% else
%     u=k_clf-(c_x+d_x*k_clf-rho*Gamma_x)/(d_x*d_x.')*d_x.';
% end
% u=u.';
% end

%% Imcompatible case: strategy 2
function [u] = Universal_Formula(a_x,b_x,c_x,d_x,Init)
global Init
kappa=1;
rho=0.01;

Sigma_x=sqrt(a_x^2+(b_x*b_x.'));
Gamma_x=sqrt(c_x^2+d_x*d_x.');
k_clf=-(a_x+kappa*Sigma_x)/(1/Init.p_sc+b_x*b_x.')*b_x;
k_cbf=-(c_x-rho*Gamma_x)/(d_x*d_x.')*d_x;

w_x=(a_x+kappa*Sigma_x)*d_x*d_x.'-(c_x-rho*Gamma_x)*b_x*d_x.';
v_x=(a_x+kappa*Sigma_x)*d_x*b_x.'-(c_x-rho*Gamma_x)*(1/Init.p_sc+b_x*b_x.');
R_x_bar=[b_x*b_x.'+1/Init.p_sc,-b_x*d_x.';-b_x*d_x.',d_x*d_x.'];

lamda_bar=inv(R_x_bar)*[(a_x+kappa*Sigma_x);-(c_x-rho*Gamma_x)];
lamda_bar_1=lamda_bar(1);
lamda_bar_2=lamda_bar(2);
% gamma_bar_1=-lamda_bar_1*b_x/(k_clf*k_clf.')*k_clf.';
% gamma_bar_2=-lamda_bar_2*b_x/(k_cbf*k_cbf.')*k_cbf.';

%% Domain of sets
if a_x+kappa*Sigma_x>=0 && v_x<0
   u=k_clf;
end

if c_x-rho*Gamma_x<=0 && w_x<0
   u=k_cbf;
end


if w_x>=0 && v_x>=0 
u=-lamda_bar_1*b_x+lamda_bar_2*d_x;
end

if a_x+kappa*Sigma_x<0 && c_x-rho*Gamma_x>0
    u=zeros(1,length(b_x));
end
end




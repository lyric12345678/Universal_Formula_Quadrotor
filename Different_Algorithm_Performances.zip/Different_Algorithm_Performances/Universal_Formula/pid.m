function [pid_output] = pid(Des_state,Est_state,PID_Coeff)
persistent pid_prevError
if isempty(pid_prevError)
    %PID: Error variable
    pid_prevError=Des_state-Est_state;
else
    %PID: Error variable
    pid_Error=Des_state-Est_state;
    %PID: Error Derivative
    pid_Error_derivative=(pid_Error-pid_prevError)/Init.pid_dt;
    %PID: Error Integral
    pid_Error_integral=pid_Error*Init.pid_dt;
    %Compute the output
    pid_output=PID_Coeff(1)*pid_Error+PID_Coeff(2)*pid_Error_integral+PID_Coeff(3)*pid_Error_derivative;
    %Set the pid_Error for the next iteration.
    pid_prevError=pid_Error;
end
end


function [F,M,setpoint,Attitude]=Controller(Flag_controller,setpoint,state)
%Flag_controller=1: PID controller
%Flag_controller=2: Geometric controller
%Flag_controller=3: MPC controller
switch Flag_controller  
    case 1
    [F,M,setpoint]=PID_Controller(setpoint,state);
    case 2
    [F,M]=CLF_CBF_QP(setpoint,state);
    case 3
    [F,M]=MPC_Controller(setpoint,state);
    case 4
    [F,M,setpoint,Attitude]=Universal_Controller(setpoint,state);
    otherwise
    F=[];M=[];
end
end


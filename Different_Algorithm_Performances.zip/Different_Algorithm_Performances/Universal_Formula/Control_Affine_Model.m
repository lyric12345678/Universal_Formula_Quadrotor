function [f,g]=Control_Affine_Model(state)
global Init
% state
% Inertial frame
x = state(1,:);
y = state(2,:);
z = state(3,:);
% Vehicle, Vehicle 1, Vehicle 2 frames
phi   = state(4,:);
theta = state(5,:);
psi   = state(6,:);
% Body frame
u = state(7,:);
v = state(8,:);
w = state(9,:);
% Body frame
p = state(10,:);
q = state(11,:);
r = state(12,:);

% Six degree of the freedom model
% Kinematics

% Translation
Pos_dot = RotMat(phi, theta, psi, 5)*[u; v; w]; % Inertial frame

% Rotational

Eul_dot = RotMat(phi, theta, psi, 7)*[p; q; r]; % Diff Vehicle frames

% Translation Dynamics

Vel_dot   =[r*v-q*w;
    p*w-r*u;
    q*u-p*v] + RotMat(phi, theta, psi, 4)*[0; 0; Init.g];  % Body frame

% Rotation Dynamics

Att_dot = [ ((Init.inertia(2,2)- Init.inertia(3,3))/(Init.inertia(1,1)))*q*r;
    ((Init.inertia(3,3) - Init.inertia(1,1))/(Init.inertia(2,2)))*p*r;
    ((Init.inertia(1,1) - Init.inertia(2,2))/(Init.inertia(3,3)))*p*r; ]; % Body frame


%% Construct functions f(x) and g(x)
f=[Pos_dot,Eul_dot,Vel_dot,Att_dot];
g.control_1=[0,0,0,0,0,0,0,0,-1/Init.m,0,0,0];
g.control_2=[0,0,0,0,0,0,0,0,0,1/(Init.inertia(1,1)),0,0];
g.control_3=[0,0,0,0,0,0,0,0,0,0,1/(Init.inertia(2,2)),0];
g.control_4=[0,0,0,0,0,0,0,0,0,0,0,1/(Init.inertia(3,3))];

end


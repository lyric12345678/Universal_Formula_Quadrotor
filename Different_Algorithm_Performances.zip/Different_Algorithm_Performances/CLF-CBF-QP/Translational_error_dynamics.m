function Pos_ddot= Translational_error_dynamics (setpoint, state)
% X = [x,y,z,phi,theta,psi,u,v,w,p,q,r]; State Definition 
  global Ref_info Init
  % Inertial frame
    x = state(1,:);         xd = setpoint(1,:);
    y = state(2,:);         yd = setpoint(2,:);
    z = state(3,:);         zd = setpoint(3,:);
   % Desired acceleration and velocity are assumed to be zero
   xd_ddot = Ref_info(7,1);  xd_dot = Ref_info(4,1); %
   yd_ddot = Ref_info(8,1);  yd_dot = Ref_info(5,1); % 
   zd_ddot = Ref_info(9,1);  zd_dot = Ref_info(6,1); % 
% Body frame 
    u = state(7,:);
    v = state(8,:);
    w = state(9,:);
% Vehicle, Vehicle 1, Vehicle 2 frames
    phi   = state(4,:);
    theta = state(5,:);
    psi   = state(6,:);
% Current velocity and position
   Pos_dot_outer =  RotMat(phi, theta, psi, 5)*[u; v; w];
   x_dot = Pos_dot_outer (1);
   y_dot = Pos_dot_outer (2);
   z_dot = Pos_dot_outer (3);
 
   Pos_ddot= [ xd_ddot + Init.PID_x(3)*(xd_dot-x_dot) + Init.PID_x(1)*(xd-x)
               yd_ddot + Init.PID_y(3)*(yd_dot-y_dot) + Init.PID_y(1)*(yd-y)
               zd_ddot + Init.PID_z(3)*(zd_dot-z_dot) + Init.PID_z(1)*(zd-z) ];        
    


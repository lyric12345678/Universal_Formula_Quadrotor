function state=Dynamic_model_Discrete(state,u)
global Init
Joint_state= [state;u];

[t, XXn] = rk4_m('state_fun', 0, Init.Model_update, Init.Model_update, Joint_state);
state = XXn(1:12,2);
end


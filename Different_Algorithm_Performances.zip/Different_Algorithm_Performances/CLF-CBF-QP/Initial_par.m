function Init=Initial_par()
%% Initial parameters for quadrotor modeling
%All details about the following parameters can be found in paper "Luukkonen, T., 2011. Modelling 
%and control of quadcopter. Independent research project in applied
%mathematics, Espoo, 22, p.22." (Page 7)
%Physical constants
Init.m=0.34;                                                               %Total mass of the quadrotor
Init.inertia=diag([321862.60*10^-9,305825.42*10^-9,576255.87*10^-9]);     %Inertia (we assume that the inertia matrix is a diagnal matrix)
Init.arm_length=0.088388;                                                  %Arm length of the quadrotor
Init.rotor_radius=23.1348*1e-3;                                            %Rotor radius of the quadrotor
Init.g=9.81;                                                               %Gravity
Init.thrust_const=2.98e-6;                                                 %Lift/Thrust constant
Init.drag_const=1.14e-7;                                                   %Drag constant
Init.I_M=3.357*1e-5;
Init.A_xyz=0.25;                                                           %Drag force coefficients for velocities (see equation (21))


%% Inital parameters for reference trajectory
Init.total_time=20;                                                        %Total simulation time is set to be 20
Init.time_interval=0.01;                                                   %The data is generated with the frequency of 100Hz

% %% Initial parameters for PID controllers
% %Updating rate for the position controller
% Init.position_dt=0.01;
% %position controller
% Init.PID_x=[2.0,0.0,0.0].';                                                %[k_{x,P},k_{x,I},k_{x,D}].'
% Init.PID_y=[2.0,0.0,0.0].';                                                %[k_{y,P},k_{y,I},k_{y,D}].'
% Init.PID_z=[2.0,0.5,0.0].';                                                %[k_{z,P},k_{z,I},k_{z,D}].'
% %velocity controller
% Init.PID_u=[25.0,1.0,0.0].';                                               %[k_{u,P},k_{u,I},k_{u,D}].'
% Init.PID_v=[25.0,1.0,0.0].';                                               %[k_{v,P},k_{v,I},k_{v,D}].'
% Init.PID_w=[3.0,1.0,1.5].';                                                %[k_{w,P},k_{w,I},k_{w,D}].'
% %Updating rate for the attitude controller
% Init.attitude_dt=1/250;
% %attitude controller
% Init.PID_phi=[6.0,3.0,0.0].';                                              %[k_{phi,P},k_{phi,I},k_{phi,D}].'
% Init.PID_theta=[6.0,3.0,0.0].';                                            %[k_{theta,P},k_{theta,I},k_{theta,D}].'
% Init.PID_psi=[6.0,1.0,0.35].';                                             %[k_{psi,P},k_{psi,I},k_{psi,D}].'
% %attitude rate controller
% Init.PID_p=[250.0,500.0,2.5].';                                            %[k_{psi,P},k_{psi,I},k_{psi,D}].'
% Init.PID_q=[250.0,500.0,2.5].';                                            %[k_{theta,P},k_{theta,I},k_{theta,D}].'
% Init.PID_r=[120.0,16.7,0].';                                               %[k_{yaw,P},k_{yaw,I},k_{yaw,D}].'

% %% Initial parameters for PID controllers
% %Flag_Traj=3: Circular curve
% %position controller
% Init.PID_x=[16.0,0.0,5.6].';                                                %[k_{x,P},k_{x,I},k_{x,D}].'
% Init.PID_y=[16.0,0.0,5.6].';                                                %[k_{y,P},k_{y,I},k_{y,D}].'
% Init.PID_z=[16.0,0.0,7.6].';                                                %[k_{z,P},k_{z,I},k_{z,D}].'
% %attitude controller
% Init.PID_phi=[324.0,0.0,34.2].';                                              %[k_{phi,P},k_{phi,I},k_{phi,D}].'
% Init.PID_theta=[324.0,0.0,34.2].';                                            %[k_{theta,P},k_{theta,I},k_{theta,D}].'
% Init.PID_psi=[144.0,0.0,22.8].';                                             %[k_{psi,P},k_{psi,I},k_{psi,D}].'

%% Initial parameters for PID controllers
%Flag_Traj=3: Circular curve
%position controller
Init.PID_x=[3.0,0.0,3.6].';                                                %[k_{x,P},k_{x,I},k_{x,D}].'
Init.PID_y=[3.0,0.0,3.6].';                                                %[k_{y,P},k_{y,I},k_{y,D}].'
Init.PID_z=[3.0,0.0,3.0].';                                                %[k_{z,P},k_{z,I},k_{z,D}].'
%attitude controller
Init.PID_phi=[380.0,0.0,40.0].';                                              %[k_{phi,P},k_{phi,I},k_{phi,D}].'
Init.PID_theta=[380.0,0.0,40.0].';                                            %[k_{theta,P},k_{theta,I},k_{theta,D}].'
Init.PID_psi=[380.0,0.0,40.0].';                                             %[k_{psi,P},k_{psi,I},k_{psi,D}].'


% %% Initial parameters for PID controllers
% %Flag_Traj=3: Circular curve
% %position controller
% Init.PID_x=[10.0,0.0,14].';                                              %[k_{x,P},k_{x,I},k_{x,D}].'
% Init.PID_y=[10.0,0.0,14].';                                              %[k_{y,P},k_{y,I},k_{y,D}].'
% Init.PID_z=[10.0,0.0,14].';                                              %[k_{z,P},k_{z,I},k_{z,D}].'
% %attitude controller
% Init.PID_phi=[400,0.0,50].';                                             %[k_{phi,P},k_{phi,I},k_{phi,D}].'
% Init.PID_theta=[400,0.0,50].';                                           %[k_{theta,P},k_{theta,I},k_{theta,D}].'
% Init.PID_psi=[200.0,0.0,50].';                                           %[k_{psi,P},k_{psi,I},k_{psi,D}].'


%% Simulation parameter (For simplicity, we keep the upadating date to be the same as the reference trajectory)
Init.Simulation_time=Init.total_time;
Init.Model_update=Init.time_interval;
Init.Frame=Init.Simulation_time/Init.Model_update+1;
Init.State_Dim=12;

%% Parameters for ECBF
Init.K_ecbf=[4,4].';
Init.H=eye(2);


%% Slack Variable
Init.p_sc=50;
end


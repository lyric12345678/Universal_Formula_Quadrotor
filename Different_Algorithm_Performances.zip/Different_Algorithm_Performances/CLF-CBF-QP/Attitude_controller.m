function [M_d]=Attitude_controller(setpoint,state)
%% Construct translational error dynamics
Att_ddot = Rotational_error_dynamics(setpoint,state);
% Required moments are calculated in inner loop 
M_d = inner_loop_sol(Att_ddot); 
% Limiter block : Moments
M_d(M_d >  .102*4) =  .102*4;
M_d(M_d < -.102*4) = -.102*4;
end


function [c_state,d_state] = Generate_MultipleCBF_Paramters(x,y,f,Obstacle_1,Obstacle_2,Obstacle_3)
global Init
%% Three Obstacles
eta=1;
h_1=(x-Obstacle_1.center(1))^2+(y-Obstacle_1.center(2))^2-Obstacle_1.radius^2;
h_2=(x-Obstacle_2.center(1))^2+(y-Obstacle_2.center(2))^2-Obstacle_2.radius^2;
h_3=(x-Obstacle_3.center(1))^2+(y-Obstacle_3.center(2))^2-Obstacle_3.radius^2;
doth_1=[2*(x-Obstacle_1.center(1)),2*(y-Obstacle_1.center(2))]*(f(1:2)).';
doth_2=[2*(x-Obstacle_2.center(1)),2*(y-Obstacle_2.center(2))]*(f(1:2)).';
doth_3=[2*(x-Obstacle_3.center(1)),2*(y-Obstacle_3.center(2))]*(f(1:2)).';
xi=exp(-eta*h_1)+exp(-eta*h_2)+exp(-eta*h_3);
zeta=exp(-eta*h_1)*doth_1+exp(-eta*h_2)*doth_2+exp(-eta*h_3)*doth_3;
p_x=-eta*(exp(-eta*h_1)*doth_1^2+exp(-eta*h_2)*doth_2^2+exp(-eta*h_3)*doth_3^2);
xi_dot=-eta*zeta;
s_x=(exp(-eta*h_1)+exp(-eta*h_2)+exp(-eta*h_3))*(2*f(1)^2+2*f(2)^2);
t_x=exp(-eta*h_1)*[2*(x-Obstacle_1.center(1)),2*(y-Obstacle_1.center(2))]+...
    exp(-eta*h_2)*[2*(x-Obstacle_2.center(1)),2*(y-Obstacle_2.center(2))]+...
    exp(-eta*h_3)*[2*(x-Obstacle_3.center(1)),2*(y-Obstacle_3.center(2))];
dot_h=zeta/xi;
h=-1/eta*log(xi);
h_collect=[h,dot_h].';
c_state=-xi_dot*zeta/(xi^2)+1/xi*(p_x+s_x)+Init.K_ecbf.'*h_collect;
d_state=1/xi*t_x;

% %% Special Case: One Obstacle
% eta=10;
% h_1=(x-Obstacle_1.center(1))^2+(y-Obstacle_1.center(2))^2-Obstacle_1.radius^2;
% doth_1=[2*(x-Obstacle_1.center(1)),2*(y-Obstacle_1.center(2))]*(f(1:2)).';
% xi=exp(-eta*h_1);
% h=-1/eta*log(xi);
% 
% zeta=exp(-eta*h_1)*doth_1;
% xi_dot=-eta*zeta;
% 
% 
% p_x=-eta*(exp(-eta*h_1)*doth_1^2);
% s_x=exp(-eta*h_1)*(2*f(1)^2+2*f(2)^2);
% t_x=exp(-eta*h_1)*[2*(x-Obstacle_1.center(1)),2*(y-Obstacle_1.center(2))];
% dot_h=zeta/xi;
% 
% h_collect=[h,dot_h].';
% c_state=-xi_dot*zeta/(xi^2)+1/xi*(p_x+s_x)+Init.K_ecbf.'*h_collect;
% d_state=1/xi*t_x;

end



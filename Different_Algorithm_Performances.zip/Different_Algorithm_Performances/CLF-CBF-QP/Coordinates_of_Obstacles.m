function [Obstacle] = Coordinates_of_Obstacles(Obstacle)
Obstacle.number_of_sample=25;
t=linspace(0,pi,Obstacle.number_of_sample);
p=linspace(0,2*pi,Obstacle.number_of_sample);
[theta,phi]=meshgrid(t,p);
Obstacle.x=Obstacle.center(1)+Obstacle.radius*sin(theta).*sin(phi);
Obstacle.y=Obstacle.center(2)+Obstacle.radius*sin(theta).*cos(phi);
Obstacle.z=Obstacle.center(3)+Obstacle.radius*cos(theta);
end


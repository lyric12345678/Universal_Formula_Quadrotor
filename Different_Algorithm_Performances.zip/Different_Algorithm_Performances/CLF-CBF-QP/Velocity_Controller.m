function [thrust,attitude]=Velocity_Controller(setpoint,stateEst)
cosyaw=cos(stateEst.yaw/180*pi);
sinyaw=sin(stateEst.yaw/180*pi);
%The Estimated velocity in body frame (obtained from estimators)
stateEst_body_u=stateEst.u*cosyaw+stateEst.v*sinyaw;
stateEst_body_v=-stateEst.u*sinyaw+stateEst.v*cosyaw;
%Compute desired roll and pitch 
[setpoint.phi,pidX_prevError] = pid(setpoint_body_u,stateEst_body_x,pidX_prevError,Init.PID_x);
[setpoint.theta,pidY_prevError] =pid(setpoint_body_v,stateEst_body_y,pidY_prevError,Init.PID_y);

%Compute thrust_raw
[setpoint.theta,pidY_prevError] =pid(setpoint_body_v,stateEst_body_y,pidY_prevError,Init.PID_y);

end


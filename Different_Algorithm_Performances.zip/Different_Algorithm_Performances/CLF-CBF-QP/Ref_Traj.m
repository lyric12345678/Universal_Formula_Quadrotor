function x_ref= Ref_Traj(Flag_Traj,Init,t)
global Ref_info
switch Flag_Traj
    case 1
        %Example 4: Straight line
        %Acceleration information
        Acceleration_des_X=-0.32*sin(0.4*t);
        Acceleration_des_Y=-0.32*cos(0.4*t);
        Acceleration_des_Z=0;
        %Velocity information
        Velocity_des_X=0.8*cos(0.4*t);
        Velocity_des_Y=-0.8*sin(0.4*t);
        Velocity_des_Z=0;
        %Position information
        x_prev=Ref_info(1:3);
        %         pos_des_X=x_prev(1)+Velocity_des_X*Init.time_interval;
        %         pos_des_Y=x_prev(2)+Velocity_des_Y*Init.time_interval;
        %         pos_des_Z=x_prev(3)+Velocity_des_Z*Init.time_interval;
        pos_des_X=2*sin(0.4*t);
        pos_des_Y=2*cos(0.4*t);
        pos_des_Z=2;
        %Reference Trajectory
        x_ref=[pos_des_X;pos_des_Y;pos_des_Z;Velocity_des_X;Velocity_des_Y;Velocity_des_Z;Acceleration_des_X;Acceleration_des_Y;Acceleration_des_Z];    
        
    otherwise
        x_ref=[];
end

% %% Plot of the reference trajectory
% figure(1)
% plot3(x_ref(1,:),x_ref(2,:),x_ref(3,:),'r--','Markersize',3,'linewidth',2)
% % axis([-60,60,-60,60,-60,60])
% grid on
% set(gca,'FontSize',23)
% set (gcf,'Position',[200,200,1000,800], 'color','w')
% xlabel('X-Direction (m)')
% ylabel('Y-Direction (m)')
% zlabel('Z-Direction (m)')
% legend('Ref')
end


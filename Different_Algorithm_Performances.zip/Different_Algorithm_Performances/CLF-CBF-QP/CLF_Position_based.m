function Pos_ddot= CLF_Position_based (setpoint, state)
% X = [x,y,z,phi,theta,psi,u,v,w,p,q,r]; State Definition
global Ref_info Init
% Inertial frame
x = state(1,:);         xd = setpoint(1,:);
y = state(2,:);         yd = setpoint(2,:);
z = state(3,:);         zd = setpoint(3,:);
% Desired acceleration and velocity are assumed to be zero
xd_ddot = Ref_info(7,1);  xd_dot = Ref_info(4,1); %
yd_ddot = Ref_info(8,1);  yd_dot = Ref_info(5,1); %
zd_ddot = Ref_info(9,1);  zd_dot = Ref_info(6,1); %
% Body frame
u = state(7,:);
v = state(8,:);
w = state(9,:);

f(1)=state(7,:);
f(2)=state(8,:);
f(3)=state(9,:);
% Vehicle, Vehicle 1, Vehicle 2 frames
phi   = state(4,:);
theta = state(5,:);
psi   = state(6,:);
% Current velocity and position
Pos_dot_outer =  RotMat(phi, theta, psi, 5)*[u; v; w];
x_dot = Pos_dot_outer (1);
y_dot = Pos_dot_outer (2);
z_dot = Pos_dot_outer (3);

gamma_1=0.8;   %k7
gamma_2=0.6;   %k9
gamma_3=1.5;   %k11

%% Altitude Controller
%CLF Parameters --- Altitude
ez=z-zd;
eaux_vz=(z_dot-zd_dot)+gamma_3*ez;
a_z=[(z_dot-zd_dot),eaux_vz]*[ez,-zd_ddot+gamma_3*(z_dot-zd_dot)].';
b_z=eaux_vz;
% u_z=-(a_z+sqrt(a_z^2+(b_z*b_z.')))/(b_z*b_z.')*b_z.';

%% CBF Parameters --- Altitude
eta=10;
z_min=1.8;
z_max=2.2;
h_z1=z-z_min;
h_z2=z_max-z;
doth_z1=f(3);
doth_z2=-f(3);
xi=exp(-eta*h_z1)+exp(-eta*h_z2);
zeta=exp(-eta*h_z1)*doth_z1+exp(-eta*h_z2)*doth_z2;
p_x=-eta*(exp(-eta*h_z1)*doth_z1^2+exp(-eta*h_z2)*doth_z2^2);
xi_dot=-eta*zeta;
s_x=0;
t_x=exp(-eta*h_z1)-exp(-eta*h_z2);
dot_hz=zeta/xi;
h_z=-1/eta*log(xi);
hz_collect=[h_z,dot_hz].';
c_z=-xi_dot*zeta/(xi^2)+1/xi*(p_x+s_x)+Init.K_ecbf.'*hz_collect;
d_z=1/xi*t_x;

kappa=1;
rho=0.01;
Sigma_x=sqrt(a_z^2+(b_z*b_z.'));
Gamma_x=sqrt(c_z^2+(d_z*d_z.'));
H=[1,0;0,Init.p_sc];
F_cost=zeros(2,1);
A=[b_z, -1;-d_z, 0];
b=[-a_z-kappa*Sigma_x;c_z-rho*Gamma_x];
u_z= quadprog(H,F_cost,A,b);
u_z=u_z(1);

%% X-Y lateral Controller
%CLF Parameters --- X-Y position
ex=x-xd;ey=y-yd;
eaux_vx=(x_dot-xd_dot)+gamma_1*ex;eaux_vy=(y_dot-yd_dot)+gamma_2*ey;

a_state = [ex,ey,eaux_vx,eaux_vy]*[(x_dot-xd_dot),(y_dot-yd_dot),-xd_ddot+gamma_1*(x_dot-xd_dot),-yd_ddot+gamma_2*(y_dot-yd_dot)].';
b_state =[eaux_vx,eaux_vy];

%CBF Parameters --- X-Y position
[Obstacle_1,Obstacle_2,Obstacle_3]= Add_Obstacle();
%A composition of the CBF


% [c_state,d_state] = Generate_CBF_Paramters(x,y,f,Obstacle_1);
[c_state,d_state] = Generate_MultipleCBF_Paramters(x,y,f,Obstacle_1,Obstacle_2,Obstacle_3);
kappa=1;
rho=0.01;
Sigma_x=sqrt(a_state^2+(b_state*b_state.'));
Gamma_x=sqrt(c_state^2+(d_state*d_state.'));
H=[1,0,0;0,1,0;0,0,Init.p_sc];
F=zeros(3,1);
A=[b_state, -1;-d_state, 0];
b=[-a_state-kappa*Sigma_x;c_state-rho*Gamma_x];
u_xy = quadprog(H,F,A,b);

% H=eye(2);
% f=zeros(2,1);
% A=[b_state;-d_state];
% b=[-a_state-kappa*Sigma_x;c_state-rho*Gamma_x];
% u_xy = quadprog(H,f,A,b);

Pos_ddot=[u_xy(1:2);u_z];
end



















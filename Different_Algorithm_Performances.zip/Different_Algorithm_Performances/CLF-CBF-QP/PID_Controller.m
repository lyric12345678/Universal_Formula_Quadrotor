function [F,M,setpoint]=PID_Controller(setpoint,state)
%The theoretic interpretation of the  position controller and attitude
%controller can be found in paper "Luis, Carlos, and J�r�me Le Ny. "Design
%of a trajectory tracking controller for a nanoquadcopter."
% %% Yaw Controller
% [Yaw]=Yaw_controller(setpoint,state);

%% Position controller
%We split the position controller into two parts: Altitude controller and
%X-Y position controller
[F,Attitude]=Position_controller(setpoint,state);

%% Attitude controller
setpoint(4:6)=[Attitude.phi_d,Attitude.theta_d,Attitude.psi_d];
[M]=Attitude_controller(setpoint,state);
end


function [Thrust_d,Attitude]=Position_QP_controller(setpoint,state)
%% Construct translational error dynamics
Pos_ddot= CLF_Position_based (setpoint, state);
% % HOCBF
% [Pos_ddot]=HOCBF(Pos_ddot,state);
Outer_loop_solution = outer_loop_sol(Pos_ddot);
Thrust_d = Outer_loop_solution (1);
Attitude.phi_d    = Outer_loop_solution (2);
Attitude.theta_d  = Outer_loop_solution (3);
Attitude.psi_d=setpoint(6);

% Limiter block : Angles
Attitude.phi_d (Attitude.phi_d  >  (deg2rad(75))) =  deg2rad(75);
Attitude.phi_d (Attitude.phi_d  < -(deg2rad(75))) = -deg2rad(75);
Attitude.theta_d (Attitude.theta_d  >  (deg2rad(75))) =  deg2rad(75);
Attitude.theta_d (Attitude.theta_d  < -(deg2rad(75))) = -deg2rad(75);
Attitude.psi_d (Attitude.psi_d  >  (deg2rad(75))) =  deg2rad(75);
Attitude.psi_d (Attitude.psi_d  < -(deg2rad(75))) = -deg2rad(75);

% Limiter block : thrust 
Thrust_d(Thrust_d > 8.3385) = 8.3385;
Thrust_d(Thrust_d < 0)  =  0;

end


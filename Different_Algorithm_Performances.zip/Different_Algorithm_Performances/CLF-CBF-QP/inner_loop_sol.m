function M = inner_loop_sol(Att_ddot)
global Init
% Moment matrix determination
M = [Init.inertia(1,1)*Att_ddot(1)
     Init.inertia(2,2)*Att_ddot(2)
     Init.inertia(3,3)*Att_ddot(3)];
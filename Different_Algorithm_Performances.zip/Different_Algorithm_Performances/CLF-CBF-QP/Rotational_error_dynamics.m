function Att_ddot = Rotational_error_dynamics(setpoint,state)
global Init
phi   = state(4,:);     phi_d   = setpoint(4,:);   phid_dot   = 0;      phid_ddot = 0;
theta = state(5,:);     theta_d = setpoint(5,:);   thetad_dot = 0;      thetad_ddot =0;
psi   = state(6,:);     psi_d   = setpoint(6,:);   psid_dot   = 0;      psid_ddot = 0;

% Euler angle dot
Euler_angle_dot = [state(10,:); state(11,:);state(12,:)];
phi_dot   = Euler_angle_dot(1);
theta_dot = Euler_angle_dot(2);
psi_dot   = Euler_angle_dot(3);

Att_ddot   = [ phid_ddot   + Init.PID_phi(3)*(phid_dot-phi_dot)     + Init.PID_phi(1)*(phi_d-phi)
               thetad_ddot + Init.PID_theta(3)*(thetad_dot-theta_dot) + Init.PID_theta(1)*(theta_d-theta)
               psid_ddot   + Init.PID_psi(3)*(psid_dot-psi_dot)     + Init.PID_psi(1)*(psi_d-psi)];            

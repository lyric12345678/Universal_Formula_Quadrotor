function XX_dot = state_fun(t, Joint_state)

state = Joint_state(1:12,:);                                               %System state
u_input = Joint_state(13:16,:);                                                  %Control input

%% Dynamic model 
X_dot = Quad_6dof(state,u_input);         

XX_dot = [ X_dot
           zeros(4,1) ];             
end
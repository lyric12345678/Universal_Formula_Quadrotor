function Outer_loop_solution = outer_loop_sol(Pos_ddot)  
global Init
x_ddot = Pos_ddot(1);
y_ddot = Pos_ddot(2);
z_ddot = Pos_ddot(3);
    
T_d = (Init.g-z_ddot)*Init.m; 
phi_d    = y_ddot/Init.g;
theta_d  = -x_ddot/Init.g;
% Solution from outer loop
Outer_loop_solution = [ T_d 
                        phi_d 
                        theta_d ];

end 
function [Pos_ddot]=Controller(Flag_controller,setpoint,state)
%Flag_controller=1: PID controller
%Flag_controller=2: Geometric controller
%Flag_controller=3: MPC controller
switch Flag_controller  
    case 1
    [F,M,setpoint]=PID_Controller(setpoint,state);
    case 2
    [F,M]=Geometric_Controller(setpoint,state);
    case 3
%     [F,M]=MPC_Controller(setpoint,state);
    [Pos_ddot]=MPC_Controller(setpoint,state);
    otherwise
     F=[];M=[];
end
end


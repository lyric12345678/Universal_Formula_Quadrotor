function [Pos_ddot]=MPC_Controller(Ref_Pred,state)
%Follow the results in "Safety-Critical Model Predictive Control with Discrete-Time
%Control Barrier Function", we obtain two different MPC algorithms: MPC-DC
%and MPC-CBF


%% MPC-DC
%% Part 1: MPC parameters initialization
% % We should notice that the velocity, which is corresponding to state(7:9),
% % is expressed in the body frame. We need to transform it to global frame.
% phi   = state(4,:);
% theta = state(5,:);
% psi   = state(6,:);
% state(7:9)=RotMat(phi, theta, psi, 5).'*state(7:9);
MPC_DC.x_current=state;                                  %Current state
MPC_DC.Pred_Interval=0.1;                                                  %Prediction time interval
%Initialize the parameters of the dynamical model
MPC_DC.A=[eye(3),eye(3)*MPC_DC.Pred_Interval;zeros(3,3),eye(3)];
MPC_DC.B=[1/2*eye(3)*MPC_DC.Pred_Interval^2;eye(3)*MPC_DC.Pred_Interval];

%The bounds for states and control inputs
% xmin = [-5; -5; -5; -5];
% xmax = [5; 5; 5; 5];
% umin = [-1; -1];
% umax = [1; 1];

%MPC-DC parameters
MPC_DC.Q=1000*eye(6);
MPC_DC.R=eye(3);
MPC_DC.P=1000*eye(6);
MPC_DC.N=10;

%% Part 2: The information of the obstacles
[Obstacle_1,Obstacle_2,Obstacle_3] = Add_Obstacle();


%% Part 3: Construct optimization problem (to avoid obstcles)
%Define Variables
x=sdpvar(6,MPC_DC.N+1);
u=sdpvar(3,MPC_DC.N);
constraints=[];
cost=0;
u_ref=Ref_Pred(7:9,1:MPC_DC.N);
%Initial constraint--model constraints
constraints=[constraints;x(:,1)==MPC_DC.x_current];
for i=1:MPC_DC.N
    constraints=[constraints;x(:,i+1)==MPC_DC.A*x(:,i)+MPC_DC.B*u(:,i)];
    cost=cost+(x(:,i)-Ref_Pred(1:6,i)).'*MPC_DC.P*(x(:,i)-Ref_Pred(1:6,i))+(u(:,i)-u_ref(:,i)).'*MPC_DC.R*(u(:,i)-u_ref(:,i));
end

% %% MPC-DC
% %Add barrier constraints
% for i=1:MPC_DC.N
%     Barrier_constraint_1=(x(1:2,i)-Obstacle_1.center(1:2)).'*(x(1:2,i)-Obstacle_1.center(1:2))-Obstacle_1.radius^2;
%     Barrier_constraint_2=(x(1:2,i)-Obstacle_2.center(1:2)).'*(x(1:2,i)-Obstacle_2.center(1:2))-Obstacle_2.radius^2;
%     Barrier_constraint_3=(x(1:2,i)-Obstacle_3.center(1:2)).'*(x(1:2,i)-Obstacle_3.center(1:2))-Obstacle_3.radius^2;
%     constraints=[constraints;Barrier_constraint_1>=0;Barrier_constraint_2>=0;Barrier_constraint_3>=0];
% end

% MPC-CBF
gamma=0.5;
eta=1;
bound_error=0.2;
for i=1:MPC_DC.N
%     %     Add CBF (xy)
%     h_x_later_1=(x(1:2,i+1)-Obstacle_1.center(1:2)).'*(x(1:2,i+1)-Obstacle_1.center(1:2))-Obstacle_1.radius^2;
%     h_x_previous_1=(x(1:2,i)-Obstacle_1.center(1:2)).'*(x(1:2,i)-Obstacle_1.center(1:2))-Obstacle_1.radius^2;
%     h_x_later_2=(x(1:2,i+1)-Obstacle_2.center(1:2)).'*(x(1:2,i+1)-Obstacle_2.center(1:2))-Obstacle_2.radius^2;
%     h_x_previous_2=(x(1:2,i)-Obstacle_2.center(1:2)).'*(x(1:2,i)-Obstacle_2.center(1:2))-Obstacle_2.radius^2;
%     h_x_later_3=(x(1:2,i+1)-Obstacle_3.center(1:2)).'*(x(1:2,i+1)-Obstacle_3.center(1:2))-Obstacle_3.radius^2;
%     h_x_previous_3=(x(1:2,i)-Obstacle_3.center(1:2)).'*(x(1:2,i)-Obstacle_3.center(1:2))-Obstacle_3.radius^2;
%     CBF_constraint_1=h_x_later_1-gamma*h_x_previous_1;
%     CBF_constraint_2=h_x_later_2-gamma*h_x_previous_2;
%     CBF_constraint_3=h_x_later_3-gamma*h_x_previous_3;
%     constraints=[constraints;CBF_constraint_1>=0;CBF_constraint_2>=0;CBF_constraint_3>=0];
    
      %     Add CBF with Approximation
        h_x_later_1=(x(1:2,i+1)-Obstacle_1.center(1:2)).'*(x(1:2,i+1)-Obstacle_1.center(1:2))-Obstacle_1.radius^2;
        h_x_previous_1=(x(1:2,i)-Obstacle_1.center(1:2)).'*(x(1:2,i)-Obstacle_1.center(1:2))-Obstacle_1.radius^2;
        h_x_later_2=(x(1:2,i+1)-Obstacle_2.center(1:2)).'*(x(1:2,i+1)-Obstacle_2.center(1:2))-Obstacle_2.radius^2;
        h_x_previous_2=(x(1:2,i)-Obstacle_2.center(1:2)).'*(x(1:2,i)-Obstacle_2.center(1:2))-Obstacle_2.radius^2;
        h_x_later_3=(x(1:2,i+1)-Obstacle_3.center(1:2)).'*(x(1:2,i+1)-Obstacle_3.center(1:2))-Obstacle_3.radius^2;
        h_x_previous_3=(x(1:2,i)-Obstacle_3.center(1:2)).'*(x(1:2,i)-Obstacle_3.center(1:2))-Obstacle_3.radius^2;
    
        %% CBF Approximation
        xi_pre=exp(-eta*h_x_previous_1)+exp(-eta*h_x_previous_2)+exp(-eta*h_x_previous_3);
        h_pre=-1/eta*log(xi_pre);
    
        xi_later=exp(-eta*h_x_later_1)+exp(-eta*h_x_later_2)+exp(-eta*h_x_later_3);
        h_later=-1/eta*log(xi_later);
    
    
        CBF_constraint=h_later-gamma*h_pre;
        constraints=[constraints;CBF_constraint>=0];
    
        
%     % Obstacle 1 bound
%     h_zlowb_later_1=x(3,i+1)-Obstacle_1.center(3)+bound_error; %lower bound
%     h_zlow_previous_1=x(3,i)-Obstacle_1.center(3)+bound_error;
%     
%     h_zupb_later_1=Obstacle_1.center(3)+bound_error-x(3,i+1); %upper bound
%     h_zupb_previous_1=Obstacle_1.center(3)+bound_error-x(3,i);
%     
%     % Obstacle 2 bound
%     h_zlowb_later_2=x(3,i+1)-Obstacle_2.center(3)+bound_error;
%     h_zlow_previous_2=x(3,i)-Obstacle_2.center(3)+bound_error;
%     
%     h_zupb_later_2=Obstacle_2.center(3)+bound_error-x(3,i+1);
%     h_zupb_previous_2=Obstacle_2.center(3)+bound_error-x(3,i);
%     
%     % Obstacle 3 bound
%     h_zlowb_later_3=x(3,i+1)-Obstacle_3.center(3)+bound_error;
%     h_zlow_previous_3=x(3,i)-Obstacle_3.center(3)+bound_error;
%     
%     h_zupb_later_3=Obstacle_3.center(3)+bound_error-x(3,i+1);
%     h_zupb_previous_3=Obstacle_3.center(3)+bound_error-x(3,i);
%     
%     CBF_constraint_lowb_z1=h_zlowb_later_1-gamma*h_zlow_previous_1;
%     CBF_constraint_upb_z1=h_zupb_later_1-gamma*h_zupb_previous_1;
%     
%     CBF_constraint_lowb_z2=h_zlowb_later_2-gamma*h_zlow_previous_2;
%     CBF_constraint_upb_z2=h_zupb_later_2-gamma*h_zupb_previous_2;
%     
%     CBF_constraint_lowb_z3=h_zlowb_later_3-gamma*h_zlow_previous_3;
%     CBF_constraint_upb_z3=h_zupb_later_3-gamma*h_zupb_previous_3;
%     
%     
%     constraints=[constraints;CBF_constraint_lowb_z1>=0;CBF_constraint_upb_z1>=0;...
%                              CBF_constraint_lowb_z2>=0;CBF_constraint_upb_z2>=0;...
%                              CBF_constraint_lowb_z3>=0;CBF_constraint_upb_z3>=0];
end
%Add terminal cost
cost=cost+(x(:,MPC_DC.N+1)-Ref_Pred(1:6,MPC_DC.N+1)).'*MPC_DC.Q*(x(:,MPC_DC.N+1)-Ref_Pred(1:6,MPC_DC.N+1));
ops = sdpsettings('solver','ipopt','verbose',0);

%% Part 4: solve optimization
diagnostics = optimize(constraints, cost, ops);
if diagnostics.problem == 0
    feas = true;
    xopt = value(x);
    uopt = value(u);
    Jopt = value(cost);
else
    feas = false;
    xopt = [];
    uopt = [];
    Jopt = [];
end
fprintf('solver time: %f\n', diagnostics.solvertime);
Pos_ddot=uopt(:,1);

end
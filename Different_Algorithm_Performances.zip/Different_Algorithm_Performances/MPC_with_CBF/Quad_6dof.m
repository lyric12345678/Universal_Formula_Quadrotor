function X_dot = Quad_6dof(state, u_input)
global Init
% state
% Inertial frame
x = state(1,:);
y = state(2,:);
z = state(3,:);
% Vehicle, Vehicle 1, Vehicle 2 frames
phi   = state(4,:);
theta = state(5,:);
psi   = state(6,:);
% Body frame
u = state(7,:);
v = state(8,:);
w = state(9,:);
% Body frame
p = state(10,:);
q = state(11,:);
r = state(12,:);

% Control input
% omega_square  = Pwm2rad(U);
% BLDC_constant = Quad_config(km,l,b);
% Quad_force    = BLDC_constant * omega_square;

Quad_force  = u_input;
T = Quad_force(1);
L = Quad_force(2);
M = Quad_force(3);
N = Quad_force(4);

% Six degree of the freedom model
% Kinematics

% Translation
Pos_dot = RotMat(phi, theta, psi, 5)*[u; v; w]; % Inertial frame

% Rotational

Eul_dot = RotMat(phi, theta, psi, 7)*[p; q; r]; % Diff Vehicle frames

% Translation Dynamics

Vel_dot   =[r*v-q*w;
    p*w-r*u;
    q*u-p*v]+[0; 0; -T/Init.m] + RotMat(phi, theta, psi, 4)*[0; 0; Init.g];  % Body frame


% Rotation Dynamics

Att_dot = [ L/(Init.inertia(1,1)) + ((Init.inertia(2,2)- Init.inertia(3,3))/(Init.inertia(1,1)))*q*r;
    M/(Init.inertia(2,2)) + ((Init.inertia(3,3) - Init.inertia(1,1))/(Init.inertia(2,2)))*p*r;
    N/(Init.inertia(3,3)) + ((Init.inertia(1,1) - Init.inertia(2,2))/(Init.inertia(3,3)))*p*r; ]; % Body frame

X_dot = [ Pos_dot
    Eul_dot
    Vel_dot
    Att_dot];
end
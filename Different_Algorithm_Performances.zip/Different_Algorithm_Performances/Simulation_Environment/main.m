clear
clc
tic
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Objective:Simulation part of the ACC-CSL Paper "Learning High-Order Control
%Barrier Functions via Projection-to-State Safety"
%Date: Aug. 11st 2022
%Author: Ming Li
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Initial parameters of the drone
global Ref_info Init
Init=Initial_par();

%% Initial setpoint/state of the quadrotor
state=zeros(Init.State_Dim,Init.Frame);
setpoint=zeros(Init.State_Dim,Init.Frame);
state(:,1)=[0;0;0;50*pi/180;50*pi/180;10*pi/180;0;0;0;0;0;0]; % X = [x,y,z,phi,theta,psi,u,v,w,p,q,r]; Definition ;
setpoint(:,1)=zeros(Init.State_Dim,1);
Ref_info=setpoint(:,1);
for i=1:length(0:Init.time_interval:Init.Simulation_time)-1
    %% Reference Trajectory
    %Flag_Traj=1: Raise + Circle curve
    Flag_Traj=1;
    Ref_info=Ref_Traj(Flag_Traj,Init,Init.time_interval*(i-1));
    setpoint(1:3,i)= Ref_info(1:3);
    

end
toc

Xd=setpoint;
%% Adding three obstacles
r = [0.3, 0.3, 0.3];             % radii of each cyl
cnt = [0.6775,-1.8844; 0.28182,1.9802;-1.7593,-0.95163];       % [x,y] center of each cyl
height = [4,4,4];         % height of each cyl
color = [1 0 0; 0 0 1 ; 0 0.5 0];% color of each cyl
nSides = 100;           % number of "sides" of the cyl
% Create figure
figure(1)
subplot(1,2,1)
h1=plot3(Xd(1,1:end-1),Xd(2,1:end-1),Xd(3,1:end-1),'r','LineWidth',2);
hold on
% % Loop through each cylinder
% for i = 1:numel(r)
%     plotCylinderWithCaps(r(i),cnt(i,:),height(i),nSides,color(i,:));
% end
h2=plotCylinderWithCaps(r(1),cnt(1,:),height(1),nSides,color(1,:));
h3=plotCylinderWithCaps(r(2),cnt(2,:),height(2),nSides,color(2,:));
h4=plotCylinderWithCaps(r(3),cnt(3,:),height(3),nSides,color(3,:));
azimuthAngle = 45;    % Adjust this angle as needed
elevationAngle =45;  % Adjust this angle as needed
view(azimuthAngle, elevationAngle)
grid on
axis equal
plotbrowser('off')
set(gca,'FontSize',15);
hTitle = title('3-D View');
set(hTitle,'FontSize',17.5);
set(hTitle,'FontSize',17.5);
axis([-3,3,-3,3,0,4])
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1000,800], 'color','w')
xlabel('X (m)') % x-axis label
ylabel('Y (m)') % y-axis label
zlabel('Z (m)') % z-axis label
subplot(1,2,2)
plot3(Xd(1,1:end-1),Xd(2,1:end-1),Xd(3,1:end-1),'r','LineWidth',2);
hold on
% Loop through each cylinder
for i = 1:numel(r)
    plotCylinderWithCaps(r(i),cnt(i,:),height(i),nSides,color(i,:));
end
view(2)
grid on
axis equal
plotbrowser('off')
set(gca,'FontSize',15);
hTitle = title('2-D View');
set(hTitle,'FontSize',17.5);
set(hTitle,'FontSize',17.5);
axis([-3,3,-3,3,0,4])
grid on
set(gca,'FontSize',23)
set (gcf,'Position',[200,200,1000,800], 'color','w')
xlabel('X (m)') % x-axis label
ylabel('Y (m)') % y-axis label
zlabel('Z (m)') % z-axis label
legend([h1,h2,h3,h4],'Ref. Traj.','Obstacle 1', 'Obstacle 2','Obstacle 3','Location','northwest','NumColumns',2)















